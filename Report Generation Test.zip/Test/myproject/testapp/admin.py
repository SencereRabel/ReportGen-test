from django.contrib import admin
from .models import Report
from .models import Visit
from .models import Volunteer_Hour
class ReportAdmin(admin.ModelAdmin):
    list_display = ('start_date', 'end_date', 'report_type', 'download_type')
    list_filter = ('report_type', 'download_type')
    search_fields = ('report_type', 'download_type')

admin.site.register(Report, ReportAdmin)

class visitAdmin(admin.ModelAdmin):
    list_display = ('visit_date', 'student_id', 'items_taken')
    list_filter = ('student_id', 'visit_date')

admin.site.register(Visit, visitAdmin)

class Volunteer_HourAdmin(admin.ModelAdmin):
    list_display = ('volunteer_id', 'start_time', 'end_time')
    list_filter = ('volunteer_id', 'start_time', 'end_time')
admin.site.register(Volunteer_Hour, Volunteer_HourAdmin)
