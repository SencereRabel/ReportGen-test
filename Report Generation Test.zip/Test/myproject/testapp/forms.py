from django import forms
from .models import Report

class ReportForm(forms.ModelForm):
    class  Meta:
        model = Report
        fields = ['start_date','end_date','download_type','report_type']
        widgets = {
            'start_date': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
            'end_date': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
            'report_type': forms.RadioSelect(),
            'download_type': forms.RadioSelect(),
        }
