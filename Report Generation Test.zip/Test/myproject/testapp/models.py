from django.db import models
from django.utils import timezone

from django.db.models import F, ExpressionWrapper, DurationField, Sum
from django.core.validators import MinValueValidator, MaxValueValidator
# Report model
class Report(models.Model):
    REPORT_TYPE_CHOICES = [
        ('volunteer_hours', 'Volunteer Hours'),
        ('guest_visits', 'Guest Visits')
    ]
    DOWNLOAD_TYPE_CHOICES = [
        ('download_report', 'Download Report'),
        ('download_data', 'Download Data')
    ]

    start_date = models.DateTimeField(default=timezone.now)
    end_date = models.DateTimeField(default=timezone.now)
    report_type = models.CharField(max_length=100, choices=REPORT_TYPE_CHOICES, default='guest_visits')
    download_type = models.CharField(max_length=100, choices=DOWNLOAD_TYPE_CHOICES, default='download_report')

    def get_visits(self):
            return Visit.objects.filter(visit_date__range=(self.start_date, self.end_date))
    
    def get_volunteer_hours(self):
            return Volunteer_Hour.objects.filter(start_time__range=(self.start_date, self.end_date))
    
    def get_total_volunteer_hours(self):
        return (
            Volunteer_Hour.objects
            .filter(start_time__range=(self.start_date, self.end_date))
            .annotate(
                duration=ExpressionWrapper(F('end_time') - F('start_time'), output_field=DurationField())
            )
            .values('volunteer_id')
            .annotate(total_hours=Sum('duration'))
            .order_by('volunteer_id')
        )

#visit model
class Visit(models.Model):
     
    student_id = models.IntegerField()
    items_taken =  models.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(10)])
    visit_date = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"Visit by Student ID {self.student_id} on {self.visit_date}"
    
#volunteer hours model
class Volunteer_Hour(models.Model):
     
    volunteer_id = models.IntegerField()
    start_time = models.DateTimeField(default=timezone.now)
    end_time = models.DateTimeField(default=timezone.now)
    
    def hours(self):
         return (self.end_time - self.start_time).total_seconds() / 3600
    
    def __str__(self):
        return f"Volunteer ID {self.volunteer_id} from {self.start_time} to {self.end_time}"
    
    
   
 
