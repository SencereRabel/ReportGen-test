from django.urls import path
from .views import *

urlpatterns = [
    path('', generate_report, name='report'),
    path('report/<int:report_id>/', report_detail, name='report_detail'),
]
