from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponse
from django.db.models import Sum
from .forms import ReportForm
from .models import Report
# Create your views here.

def report_detail(request, report_id):
    report_instance = get_object_or_404(Report, id=report_id)

    if report_instance.report_type == 'volunteer_hours':
        volunteer_hours = report_instance.get_volunteer_hours()
        total_volunteer_hours = report_instance.get_total_volunteer_hours()
        context = {
            'total_volunteer_hours' : total_volunteer_hours,
            'report': report_instance,
            'volunteer_hours': volunteer_hours,
        }

    elif report_instance.report_type == 'guest_visits':
        visits = report_instance.get_visits()
        total_items_taken = visits.aggregate(Sum('items_taken'))['items_taken__sum']
        total_visits = visits.count()
        context = {
            'report': report_instance,
            'visits': visits,
            'total_items_taken': total_items_taken,
            'total_visits': total_visits,
        }
    return render(request, 'report_detail.html', context)

def generate_report(request):
        form = ReportForm()
        if request.method == 'POST':
            form = ReportForm(request.POST)
            if form.is_valid():
                report_instance = form.save()
                if report_instance.download_type == 'download_report':
                    return redirect('report_detail', report_id=report_instance.id)

                elif report_instance.download_type == 'download_data':
                    return 0
        else:
            form = ReportForm()
        context={'form':form}
        return render(request, 'report.html',context)